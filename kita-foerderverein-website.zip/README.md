# Kita-Förderverein Website

## Schnellstart
1. `index.html`, `style.css`, `impressum.html` und `datenschutz.html` zusammen hochladen.
2. In `index.html` Namen, Adresse, E-Mail, Telefon und Termine ersetzen.
3. Für GitHub Pages: Repository auf GitHub anlegen, Dateien hochladen und unter Settings → Pages die Veröffentlichung aus dem `main`-Branch aktivieren.

## Wichtig
Impressum und Datenschutz sind Platzhalter und sollten vor der Veröffentlichung an die tatsächlichen Vereinsdaten und eingesetzten Dienste angepasst werden.
